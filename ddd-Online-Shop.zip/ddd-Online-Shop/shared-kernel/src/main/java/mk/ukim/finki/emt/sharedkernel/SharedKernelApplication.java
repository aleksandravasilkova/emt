package mk.ukim.finki.emt.sharedkernel;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SharedKernelApplication {

    public static void main(String[] args) {
        SpringApplication.run(SharedKernelApplication.class, args);
    }

}
