package mk.ukim.finki.emt.sharedkernel.domain.finfancial;

public enum Currency {
    EUR,USD,MKD
}
