package mk.ukim.finki.emt.sharedkernel.domain.category;

public enum Category {
    SPORTCLOTHES,EQUIPMENTS,ACCESORIES;
}
