package mk.ukim.finki.emt.ordermanagement.service.forms;

import lombok.Data;
import lombok.NonNull;
import mk.ukim.finki.emt.sharedkernel.domain.category.Category;
import org.antlr.v4.runtime.misc.NotNull;


import javax.validation.Valid;
import javax.validation.constraints.NotEmpty;
import java.util.ArrayList;
import java.util.Currency;
import java.util.List;

@Data
public class OrderForm {

    @NonNull
    private Currency currency;

    @NonNull
    private Category category;

@Valid
@NotEmpty
    private List<OrderItemForm> items = new ArrayList<>();
}

